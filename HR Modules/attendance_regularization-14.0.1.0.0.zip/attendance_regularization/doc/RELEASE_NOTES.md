## Module <attendance_regularization>

#### 15.10.2020
#### Version 14.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
