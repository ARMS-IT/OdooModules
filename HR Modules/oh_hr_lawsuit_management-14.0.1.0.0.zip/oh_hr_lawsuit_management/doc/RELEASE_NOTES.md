## Module <hr_lawsuit>

#### 31.10.2021
#### Version 14.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project
