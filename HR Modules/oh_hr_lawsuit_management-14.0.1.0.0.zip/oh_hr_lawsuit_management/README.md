OHRMS Legal Actions
---------------------
Supporting Addon for Open HRMS, Managing Legal Actions


Installation
------------
- www.odoo.com/documentation/14.0/setup/install.html
- Install our custom addon


Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.


Contacts
--------
info - info@cybrosys.com
Sreejith P - odoo@cybrosys.com
Jesni Banu - odoo@cybrosys.com

Website:
https://www.openhrms.com
https://www.cybrosys.com

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
