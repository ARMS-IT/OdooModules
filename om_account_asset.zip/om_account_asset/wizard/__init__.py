# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import asset_depreciation_confirmation_wizard
from . import asset_modify
